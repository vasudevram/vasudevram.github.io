
# PDFXMLRPCClient.py
# Author: Vasudev Ram - http://www.dancingbison.com

# This file is a part of the PDFXMLRPC software package.

# The PDFXMLRPC software is released under the BSD License.
# The following are the terms of the license.
# 
# Copyright (c) 2009, Vasudev Ram
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the following
# conditions are met:
# 
#  - Redistributions of source code must retain the above copyright
# notice, this list of conditions and the following disclaimer. 
# 
#  - Redistributions in binary form must reproduce the above 
# copyright notice, this list of conditions and the following
# disclaimer in the documentation and/or other materials
# provided with the distribution.
# 
#  - Neither the name of Vasudev Ram nor the names of any
# contributors may be used to endorse or promote products
# derived from this software without specific prior written
# permission. 
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

# --------------------------------------------------------------

# Description: 
# An XML-RPC client to enable client-server PDF creation.
# Meant to be used together with the corresponding server program,
# PDFXMLRPCServer.py.
# Uses XML-RPC.

#--------------------- imports ---------------------------------

import sys
import os
import xmlrpclib

#--------------------- module-level code -----------------------

DEBUG=0
prog_name = ""

#---------------------- debug() --------------------------------

def debug(expr, value=None, out=sys.stderr):
    global DEBUG
    if (DEBUG != 1):
        return
    if value is None:
        # print only expr if value is None
        msg = "%s\n" % (str(expr))
    else:
        # print both expr and value if value is not None
        msg = "%s = %r\n" % (str(expr), repr(value))
    out.write(msg)
    out.flush()

#------------------------ set_debug_flag() ---------------------

def set_debug_flag():
    """
    Set the flag DEBUG to 0 (False) or 1 (True) based on
    the value of the environment variable of the same name.
    If env. var. DEBUG is unset, or is set but not equal to "1",
    set DEBUG to 0, else set it to 1.
    """

    global DEBUG
    DEBUG = 0
    debug_env_var = os.getenv("DEBUG")
    if not debug_env_var in (None, "0", "1"):
        sys.stderr.write(
        "ERROR: DEBUG env. var. should be undefined, 0 or 1\n")
        sys.exit(-1)
    if debug_env_var is None:
        debug_env_var = "0"
    # Now debug_env_var is either "0" or "1", so 
    # return the debug flag based on that.
    return int(debug_env_var)

#------------------------ usage() -----------------------------

def usage():
    """
    Print a usage message.
    """
    global prog_name
    sys.stderr.write("Usage: %s port pdf_filename\n" % prog_name)

#--------------------- class PDFXMLRPCClient -------------

class PDFXMLRPCClient:

    def __init__(self, port, pdf_filename):
        """
        PDFXMLRPCClient constructor.
        """
        self._pdf_filename = pdf_filename
        try:
            self._client = xmlrpclib.Server(
            "http://localhost:" + str(port))
        except IOError, e:
            sys.stderr.write(
            "%s: Error: IOError occurred. Terminating.\n" % prog_name)
            sys.exit(1)
        except:
            sys.stderr.write(
            "%s: General Error. Terminating.\n" % prog_name)
            sys.exit(1)

        debug("Client (proxy) for XML-RPC server created at " + \
        "http://localhost:" + str(port))
        debug("self._client", self._client)

    def create_pdf_writer(self):
        """
        PDFXMLRPCClient:create_pdf_writer() method.
        """
        try:
            self._client.create_pdf_writer()
        except Exception, e:
            sys.stderr.write(
            "%s: Caught Exception in PDFXMLRPCClient.create_pdf_writer(): %s. Exiting." % (prog_name, e))
            sys.exit(1)

    def setFont(self, font_family, font_size):
        """
        PDFXMLRPCClient:setFont() method.
        """
        self._client.setFont(font_family, font_size)

    def setHeader(self, header_str):
        """
        PDFXMLRPCClient:setHeader() method.
        """
        self._client.setHeader(header_str)

    def setFooter(self, footer_str):
        """
        PDFXMLRPCClient:setFooter() method.
        """
        self._client.setFooter(footer_str)

    def writeLine(self, line):
        """
        PDFXMLRPCClient:writeLine() method.
        """
        self._client.writeLine(line)

    def savePage(self):
        """
        PDFXMLRPCClient:savePage() method.
        """
        self._client.savePage()

    def close(self):
        """
        PDFXMLRPCClient:close() method.
        """
        self._client.close()

    def get_pdf_data(self):
        """
        PDFXMLRPCClient:get_pdf_data() method.
        """
        return self._client.get_pdf_data()

#------------------- main() -------------------------------------

def main():

    """
    Main function of the program.
    """

    # Save program name for error messages.
    global prog_name
    prog_name = sys.argv[0]
    print "%s starting." % prog_name

    global DEBUG
    DEBUG = set_debug_flag()
    if DEBUG:
        print "%s: Running in debug mode." % prog_name

    debug("Checking args")

    # Check arguments.
    if (len(sys.argv) != 3):
        sys.stderr.write(
        "%s: Error: must give a port number and an output PDF filename\n" % prog_name)
        usage()
        sys.exit(1)

    # Check valid port.
    try:
        port = int(sys.argv[1])
    except ValueError, e:
        sys.stderr.write("%s: Error: Invalid integer value for port: %s\n" \
        % (prog_name, sys.argv[1]))
        sys.exit(1)
    debug("port", port)

    pdf_filename = sys.argv[2]
    debug("pdf_filename", pdf_filename)

    pxr_client = PDFXMLRPCClient(port, pdf_filename)

    debug("Before call to pxr_client.create_pdf_writer()")
    pxr_client.create_pdf_writer()
    debug("Before call to pxr_client.setFont()")
    pxr_client.setFont("Courier", 12)
    debug("Before call to pxr_client.setHeader() and pxr_client.setFooter()")
    pxr_client.setHeader("Test header")
    pxr_client.setFooter("Test footer")

    # Send 1000 lines of text to the server to convert to PDF.
    max_lines = 1000
    len_str_ml = len(str(max_lines))
    # Print progress message after every 10% of output.
    print_interval = int(max_lines * 0.1 )
    for n in range(0, max_lines):
        line = str(n).rjust(len_str_ml + 1, "-") * 16
        line = line[:80]
        if ( (n % print_interval) == 0):
            debug("before call to pxr_client.writeLine(), line# = %d" % n)
        pxr_client.writeLine(str(n).rjust(len_str_ml, " ") + ": " + line)

    debug("before call to pxr_client.savePage()")
    pxr_client.savePage()
    debug("before call to pxr_client.close()")
    pxr_client.close()
    debug("before call to pxr_client.get_pdf_data()")

    # Get back the PDF content from the client.
    pdf_data = pxr_client.get_pdf_data()
    debug("type(pdf_data.data) is ", type(pdf_data.data))
    debug("pdf_data.data.__class__ is ", pdf_data.data.__class__)
    debug("before call to open(...)")

    # Save the PDF content to a local PDF file.
    pdf_file = open(pdf_filename, "w")
    debug("before call to write(...)")
    pdf_file.write(pdf_data.data)
    pdf_file.close()
    print "Output is in file %s" % pdf_filename

#------------------- call main() --------------------------------

if __name__ == "__main__":
    main()

#------------------- EOF: PDFXMLRPCClient.py -----------

