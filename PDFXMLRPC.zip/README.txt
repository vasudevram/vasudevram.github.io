
This file was created by Vasudev Ram - http://www.dancingbison.com .

This is the README.txt file (the documentation) for the PDF XML-RPC Server and the PDF XML-RPC Client.

License: The software files in this package are open source code, released under the New BSD License - see:

http://www.opensource.org/licenses/bsd-license.php

Note: Read the entire documentation in this file before starting to install any of the software mentioned below.

1. PDFXMLRPCServer.py and PDFXMLRPCClient.py (collectively called the PDF server and PDF client in the rest of this document) are a pair of programs, a server and a client, that together allow the user to do client/server creation of PDF files from text content, over an intranet or the Internet, over XML-RPC and HTTP.

1.1. Documentation for PDFXMLRPCServer.py:

Requirements:

First install the following required software:

(Note: The installation steps given below must be done in the sequence given - i.e. install Python, then Reportlab, then xtopdf. Otherwise things will not work.)

1.1.1. Install Python v2.2 or higher. (It is preferable to get the latest stable Python version, which is v2.6.x at the time of writing this file.) Get it from http://python.org and install it, if you don't already have it. To check whether it is working, after installation, go to a terminal window (on UNIX-like systems) or a command prompt (on Windows) and type:

  python -V
  
If you get a message showing the Python version installed, it means the installation went ok. If you get some other message indicating an error, it means that Python was not installed ok. If not installed ok, get help from some local expert.

1.1.2. Install ReportLab v1.x. (Don't use v2.x since xtopdf has some issues with it.) Get it from http://www.reportlab.org and install it. Use the documentation in the Reportlab package to install it.

1.1.3. Install xtopdf v1.0. Get it as follows: go to  http://www.dancingbison.com/products.html , click on the link labelled "xtopdf", which will take you to the page http://sourceforge.net/projects/xtopdf . From there, follow the appropriate links to get to the download page for xtopdf, and download it.

Alternate site for xtopdf (which you can use if SourceForge site is down, or for a direct download):

http://www.dancingbison.com/xtopdf-1.0.tar.gz

Enter the above URL in your web browser and then click the Save option when prompted, then specify a directory to download it into.

You can use this guide for some more help with downloading and installing Reportlab and xtopdf:

http://itext.ugent.be/library/question.php?id=41

The above guide is for Windows, but the steps for UNIX-like systems will be roughly the same, except modified for UNIX-like commands, shells, uncompression tools, etc. Get the help of a Python and/or UNIX expert if needed.

After installation of xtopdf, add the directory where you installed it, to your PYTHONPATH environment variable. To do this on Windows, at the command prompt, enter:

set PYTHONPATH=%PYTHONPATH%;the_xtopdf_install_dir

where the_xtopdf_install_dir is the directory in which you extracted the xtopdf package.

To do it on UNIX-like systems, at the terminal prompt, enter:

export PYTHONPATH=$PYTHONPATH:the_xtopdf_install_dir

where the_xtopdf_install_dir is the same as explained above.

To check if xtopdf is installed ok, use the guide mentioned above (http://itext.ugent.be/library/question.php?id=41); look at step 5 in that guide (titled "Now you can install xtopdf"), and try to run some of the programs in the xtopdf package, as described in that step 5. If they run ok, it means xtopdf is installed ok.

1.1.4. Install and run the PDF XML-RPC Server:

Download the file PDFXMLRPC.zip from:

http://www.dancingbison.com/PDFXMLRPC.zip

[ Strictly speaking, if you're reading this README.txt file, it likely means that you've already downloaded the above zip file and extracted  it, since this README.txt file comes with it; but a) since it's possible that you got the README.txt some other way, and b) for completeness' sake, I'm mentioning the following anyway: ]

Extract the zip file into a directory that you create, say, /home/you/apps/pdfxmlrpc (for UNIX-like systems) or D:\You\Apps\PDFXMLRPC (for Windows).

One of the files extracted should be:
 
PDFXMLRPCServer.py

Running the PDFXMLRPC Server:

- Change to the directory you created in the step above, e.g.:

cd /home/you/apps/pdfxmlrpc 

or

cd D:\You\Apps\PDFXMLRPC

Enter:

python PDFXMLRPCServer.py 4242 

(or use some other port number instead of 4242; the port number you use should not be already be in use by some other application.)

If all is ok, you should see a few messages indicating that the server is starting. You should not get back the command prompt, since the server runs indefinitely. When you want to stop it (later, after trying out the client along with the server), just press Control-C in that terminal window / command prompt window, to stop the server.

1.1.5. Install and run the PDF XML-RPC Client:

(Since you already extracted the zip file containing both the server and the client in the step above, the file PDFXMLRPCClient.py should already be present in the directory.)

Running the PDFXMLRPC Client:

Enter:

python PDFXMLRPCClient.y 4242 out1.pdf

where the port number (4242 in this case) should be the same number that you used in the command-line to start the server above. You can, of course, use any other filename instead of out1.pdf. Note: use the name of a non-existent file, or it might get overwritten.

This above command will start the client, and it will begin communicating with the server (assuming you started the server first), sending it some lines of text, and after some seconds, it will get back the contents of that text as PDF content, and will write that PDF content to the file named out1.pdf. You should see a message saying that the output is in that file.

Now you can open that file out1.pdf in Adobe Reader, or any other PDF viewing program such as Foxit Reader, and will be able to view the PDF content created.

Note: If you need some customization of this client/server application, PDFXMLRPC, or any other Python or PDF programming work, I am available for that, on a paid basis. I also have skills in, and work with, many other technologies, such as Java, relational databases, Ruby, Linux, C, and many open source technologies. Please feel free to contact me via my business web site; the contact page is:

http://www.dancingbison.com/contact.html

I appreciate all feedback about this software. That includes bug reports and feature requests. I can't guarantee that I'll implement any requested features, but will definitely give consideration to all such requests. Also, if you're using the PDFXMLRPC software, even if you don't have any problems with it, or any feature requests, I'd appreciate your telling me how you find it, and what you use it for, if that's not confidential. I'd like this info both just to know how PDFXMLRPC is being used, and also for possible use as a testimonial with future potential clients. But if you don't wish your name to be mentioned, just let me know, and I won't use your name as a testimonial or mention you in any other way.

Thanks,
Vasudev Ram
Dancing Bison Enterprises
Software consulting and training
Biz site: http://www.dancingbison.com
Blog on software innovation: http://jugad2.blogspot.com
Twitter: @vasudevram

--------------------------- END OF FILE ---------------------------
