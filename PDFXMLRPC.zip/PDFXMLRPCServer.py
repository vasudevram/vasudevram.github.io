
# PDFXMLRPCServer.py
# Author: Vasudev Ram - http://www.dancingbison.com

# This file is a part of the PDFXMLRPC software package.

# The PDFXMLRPC software is released under the BSD License.
# The following are the terms of the license.
# 
# Copyright (c) 2009, Vasudev Ram
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the following
# conditions are met:
# 
#  - Redistributions of source code must retain the above copyright
# notice, this list of conditions and the following disclaimer. 
# 
#  - Redistributions in binary form must reproduce the above 
# copyright notice, this list of conditions and the following
# disclaimer in the documentation and/or other materials
# provided with the distribution.
# 
#  - Neither the name of Vasudev Ram nor the names of any
# contributors may be used to endorse or promote products
# derived from this software without specific prior written
# permission. 
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

# --------------------------------------------------------------

# Description: 
# An XML-RPC server to enable client-server PDF creation.
# Meant to be used together with the corresponding client program,
# PDFXMLRPCClient.py.
# Uses XML-RPC, xtopdf and ReportLab.

#--------------------- imports ---------------------------------

import os
import sys
import string
import tempfile
import SimpleXMLRPCServer
import xmlrpclib

from PDFWriter import PDFWriter

#--------------------- module-level code -----------------------

DEBUG=0
prog_name = ""

#---------------------- debug() --------------------------------

def debug(expr, value=None, out=sys.stderr):
    global DEBUG
    if (DEBUG != 1):
        return
    if value is None:
        # print only expr if value is None
        msg = "%s\n" % (str(expr))
    else:
        # print both expr and value if value is not None
        msg = "%s = %r\n" % (str(expr), repr(value))
    out.write(msg)
    out.flush()

#------------------------ set_debug_flag() ---------------------

def set_debug_flag():
    """
    Set the flag DEBUG to 0 (False) or 1 (True) based on
    the value of the environment variable of the same name.
    If env. var. DEBUG is unset, or is set but not equal to "1",
    set DEBUG to 0, else set it to 1.
    """

    global DEBUG
    DEBUG = 0
    debug_env_var = os.getenv("DEBUG")
    if not debug_env_var in (None, "0", "1"):
        sys.stderr.write(
        "ERROR: DEBUG env. var. should be undefined, 0 or 1\n")
        sys.exit(-1)
    if debug_env_var is None:
        debug_env_var = "0"
    # Now debug_env_var is either "0" or "1", so 
    # return the debug flag based on that.
    return int(debug_env_var)

#------------------------ class PDFWriterManager) --------------

class PDFWriterManager:

    def __init__(self):
        """
        PDFWriterManager constructor.
        """
        debug("Entered PDFWriterManager.__init__()")
        self.__pdf_filename = None
        self.__pw = None
        self.__pw_closed = False

    def create_pdf_writer(self):
        """
        Creates the contained PDFWriter instance.
        """
        debug("Entered PDFWriterManager.create_pdf_writer()")
        # Create a temporary filename that will be in the current
        # directory and with filename prefix "PXR_".
        #self.__pdf_filename = os.tempnam(os.getcwd(), "PXR_")
        # Get the file number (low-level IO handle) and corresponding
        # filename of a temporary filename.
        (file_num, self.__pdf_filename) = tempfile.mkstemp(prefix="PXR_")
        # Close the file since mkstemp has already opened it, and we
        # need it closed for the PDFWriter constructor.
        os.close(file_num)
        # Create a PDFWriter instance using that temporary filename.
        self.__pw = PDFWriter(self.__pdf_filename)
        return 0

    def setFont(self, font_name, font_size):
        """
        Calls setFont() on the contained PDFWriter instance.
        """
        debug("Entered PDFWriterManager.setFont()")
        if self.__pw is None:
            return
        self.__pw.setFont(font_name, font_size)
        return 0

    def setHeader(self, header_string):
        """
        Calls setHeader() on the contained PDFWriter instance.
        """
        debug("Entered PDFWriterManager.setHeader()")
        if self.__pw is None:
            return
        self.__pw.setHeader(header_string)
        return 0

    def setFooter(self, footer_string):
        """
        Calls setFooter() on the contained PDFWriter instance.
        """
        debug("Entered PDFWriterManager.setFooter()")
        if self.__pw is None:
            return
        self.__pw.setFooter(footer_string)
        return 0

    def writeLine(self, line):
        """
        Calls writeLine() on the contained PDFWriter instance.
        """
        debug("Entered PDFWriterManager.writeLine()")
        if self.__pw is None:
            return
        self.__pw.writeLine(line)
        return 0

    def savePage(self):
        """
        Calls savePage() on the contained PDFWriter instance.
        """
        debug("Entered PDFWriterManager.savePage()")
        if self.__pw is None:
            return
        self.__pw.savePage()
        return 0

    def close(self):
        """
        Calls close() on the contained PDFWriter instance.
        """
        debug("Entered PDFWriterManager.close()")
        if self.__pw is None:
            return
        self.__pw.close()
        self.__pw_closed = True
        return 0
    
    def get_pdf_data(self):
        """
        Reads the PDF file created by the contained PDFWriter instance.
        Saves it in a string; then returns the string to the calling
        XMLRPC client as Binary XML-RPC data.
        """
        debug("Entered PDFWriterManager.get_pdf_data()")
        if self.__pw is None:
            #raise RuntimeError("%s: Internal program error. " + \
            #"self.__pw is None in PDFWriterManager.get_pdf_data(). Exiting.")
            debug("self.__pw is None in PDFWriterManager.get_pdf_data() ...")
            debug("... so returning Binary('AAA')")
            ret_val = xmlrpclib.Binary("AAA")
            #return None
            return ret_val

        if not self.__pw_closed:
            #raise RuntimeError("self.__pw_closed is True in " + \
            #"PDFWriterManager.get_pdf_data(). Exiting.")
            debug("self.__pw_closed is True in PDFWriterManager.get_pdf_data() ...")
            debug("... so returning Binary('BBB')")
            ret_val = xmlrpclib.Binary("BBB")
            #return None
            return ret_val
        
        pdf_file = open(self.__pdf_filename, "r")
        debug("After pdf_file = open(...)")
        # Read the entire file into a string. May fail
        # if file is too large for available memory, 
        # unless system uses virtual memory / swap automatically.
        pdf_data = pdf_file.read()
        debug("After pdf_data = read(), pdf_data = ", pdf_data)
        pdf_file.close()
        debug("After pdf_file.close()")
        binary_pdf_data = xmlrpclib.Binary(pdf_data)
        debug("After converting pdf_data to Binary XML-RPC data")
        os.remove(self.__pdf_filename)
        debug("After os.remove(...)")
        # Return the PDF file content as Binary XML-RPC data.
        debug("Before returning the PDF file as Binary XML-RPC data")
        return binary_pdf_data

#------------------------ class PDFXMLRPCServer ---------------

class PDFXMLRPCServer:

    def __init__(self, port, logRequests=False):
        """
        PDFXMLRPCServer constructor.
        """
        global DEBUG
        debug("Entered PDFXMLRPCServer.__init__()")
    
        debug("Before creating SimpleXMLRPCServer on localhost:%d" % port)
        self.sxr_server = SimpleXMLRPCServer.SimpleXMLRPCServer(
            ("localhost", port), logRequests=False)

    def register_instance(self, pwm):
        """
        Registers the PDFWriterManager with the 
        underlying SimpleXMLRPCServer.
        """
        self.sxr_server.register_instance(pwm)

    def run(self):
        """
        Starts the underlying SimpleXMLRPCServer running.
        """
        self.sxr_server.serve_forever()

#------------------------ usage() -----------------------------

def usage():
    """
    Print a usage message.
    """
    global prog_name
    sys.stderr.write("Usage: %s port\n" % prog_name)

#------------------------ main() ------------------------------

def main():

    """
    Main function of the program.
    """

    # Save program name for error messages.
    global prog_name
    prog_name = sys.argv[0]

    global DEBUG
    DEBUG = set_debug_flag()
    if DEBUG:
        print "%s: Running in debug mode." % prog_name

    print "%s starting." % prog_name

    debug("Checking args")
    if (len(sys.argv) != 2):
        sys.stderr.write(
        "Error: must give a port number. Exiting.\n")
        usage()
        sys.exit(1)
    try:
        port = int(sys.argv[1])
    except ValueError, e:
        sys.stderr.write(
        "Error: Invalid argument for port: %s. Exiting\n" % sys.argv[1])
        sys.exit(1)

    debug("port", port)
    debug("type(port)", type(port))
    debug("%s: Before creating PDF XML-RPC server on localhost:%d" % (prog_name, port))
    pxr_server = PDFXMLRPCServer(port)
    debug("%s: Before creating PDFWriterManager" % prog_name)
    pwm = PDFWriterManager()
    debug("Before registering PDFWriterManager instance")
    pxr_server.register_instance(pwm)
    print "PDF XML-RPC server ready in a moment ..."
    pxr_server.run()

#------------------- call main() --------------------------------

if __name__ == "__main__":
    main()

#------------------- EOF: PDFXMLRPCServer.py -----------

