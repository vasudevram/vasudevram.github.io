
# vi_article.py
"""
"""

import sys
import os
import psc_util
from psc_util import *
import urllib2

def create():

    start_html()
    
    start_head()
    title("Testing DSLWiki - vi article")
    end_head()
    
    start_body()

    f = urllib2.urlopen(
        'http://www.dancingbison.com/writings/vi_quickstart.txt')
    paragraph("Extract from vi article")
    hr()
    #paragraph(f.read(100))
    #paragraph(f.read(50))
    #paragraph(f.read())
    #s = f.read()
    #preformatted(s)
    preformatted(f.read())
    hr()
    f.close()
    
    end_body()
    
    end_html()
