
import sys
import os
import psc_util
from psc_util import *

def create():

    start_html()
    
    start_head()
    title("Testing DSLWiki - listdir")
    end_head()
    
    start_body()
    
    paragraph("""This page uses the python listdir function""")
    hr()
    dir_lis = os.listdir(os.getcwd())
    start_bold()
    paragraph("Directory listing of " + os.getcwd())
    end_bold()
    hr()
    i = 1
    for fil in dir_lis:
        paragraph(str(i) + ": " + fil)
        i += 1
    hr()
    
    end_body()
    
    end_html()
