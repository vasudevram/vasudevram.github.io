
import sys
import psc_util
from psc_util import *

def create():

	start_html()

	start_head()
	title("MainPage")
	end_head()

	start_body()

	start_bold()
	paragraph("""This is MainPage""")
	end_bold()
	hr()

	start_italic()
	paragraph("""This is italic""")
	end_italic()

	start_underline()
	paragraph("""This is underline""")
	end_underline()

	link_to("faq.html", "FAQ")

	end_body()

	end_html()

