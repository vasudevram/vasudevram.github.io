
import sys
import psc_util
from psc_util import *

def create():

    start_html()
    
    start_head()
    title("Testing DSLWiki - FAQ")
    end_head()
    
    start_body()
    
    paragraph("""This is a FAQ""")
    paragraph("A horizontal rule")
    hr()
    link_to("MainPage.html", "MainPage")
    start_bold()
    paragraph("This is a FAQ")
    end_bold()
    
    end_body()
    
    end_html()
