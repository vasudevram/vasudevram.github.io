
import sys
import psc_util
from psc_util import *

def create():

    start_html()
    
    start_head()
    title("Testing DSLWiki - HTML pre tag")
    end_head()
    
    start_body()
    
    paragraph("""Some pre tagged content below""")
    hr()
    #start_bold()
    preformatted("""
    # Python code
    # Function foo.
    def foo(name):
        print "Hi", name
    # End Function foo.
    """)
    #end_bold()
    
    end_body()
    
    end_html()
