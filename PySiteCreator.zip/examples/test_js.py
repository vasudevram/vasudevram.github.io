
import sys
import psc_util
from psc_util import *

def write_js():
    paragraph("""
    <script "text=javascript">
    alert("testing JS")
    </script>
    """)
    
def create():

	start_html()

	start_head()
	title("A title")
	end_head()

	start_body()

	hr()
	paragraph("JS below here")

	hr()
	
	write_js()
	
	end_body()

	end_html()

