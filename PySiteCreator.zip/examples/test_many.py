
import sys
import psc_util
from psc_util import *

lis = [ i for i in range(1, 11) ]
lis = lis.reverse()
print "reversed lis =", (lis)

dic = {}
for k in range(1, 11):
	key = str(k)
	val = k * k
	dic[key] = val
printable_dic = [ pair for pair in dic.items() ]
print "printable_dic =", printable_dic

def create():

	start_html()

	start_head()
	title("Testing DSLWiki - TestMany")
	end_head()

	start_body()

	paragraph("Reversed list")
	paragraph(repr(lis))
 
	paragraph("The dict")
	paragraph(repr(printable_dic))

	end_body()

	end_html()

