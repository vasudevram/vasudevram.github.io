
import sys
import psc_util
from psc_util import *

def create():

    start_html()
    
    start_head()
    title("Testing DSLWiki - test_page2")
    end_head()
    
    start_body()
    
    paragraph("""This is a paragraph in test_page2""")
        
    hr()
    
    end_body()
    
    end_html()
    
