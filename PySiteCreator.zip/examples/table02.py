
import sys
import psc_util
from psc_util import *

def create_table_row(row):

	start_table_row()
	for item in row:
		start_table_detail()
		paragraph(item)
		end_table_detail()
	end_table_row()

def create_table(tno):

	tno_str = "Table %d" % tno
	paragraph("Table " + tno_str + ":")
	start_table()
	# 2 rows
	for row_num in range(1, 3):
		row = []
		row_str = "Row " + str(row_num)
		# 3 cells
		for cell_num in range(1, 4):
			cell_str = "Cell " + str(cell_num)
			row.append(row_str + ", " + cell_str)
		create_table_row(row)
	end_table()
	hr()

def create():

	start_html()

	start_head()
	title("Testing DSLWiki - Table")
	end_head()

	start_body()

	paragraph("""This is a table""")
	paragraph("A horizontal rule")
	hr()
	link_to("MainPage.html", "MainPage")
	for tno in range(1, 8):
		if (tno % 2 == 0):
			paragraph("*** Skipping table for tno = %d" % tno)
			hr()
			continue
		create_table(tno)

	end_body()

	end_html()

