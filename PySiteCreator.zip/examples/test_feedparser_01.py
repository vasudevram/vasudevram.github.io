
# test_feedparser_01.py

import sys
import psc_util
from psc_util import *

import feedparser

def create():

    ##TODO: Combine the output from all the feeds below, commented 
    ##TODO: as well as uncommented, so that all appear in the output,
    ##TODO: with suitable titles to mark them apart.
    ##TODO: Generalize this code some more, make it an API, etc.
    
    #d = feedparser.parse("http://feeds.feedburner.com/Jugad2-VasudevRamOnSoftwareInnovation")

    #d = feedparser.parse("http://feeds.feedburner.com/AVc")

    #d = feedparser.parse("http://feeds.feedburner.com/oreilly/radar/atom")

    d = feedparser.parse("http://search.twitter.com/search.atom?q=+%40vasudevram")

    start_html()
    
    start_head()
    title("Testing DSLWiki - test_feedparser_01")
    end_head()
    
    start_body()
    
    paragraph("""This is test 01 of feedparser""")
    hr()

    #paragraph(d['feed']['title'])

    keys = d['feed'].keys()
    for key in keys:
        paragraph("key: " + str(key))

    values = d['feed'].values()
    for value in values:
        paragraph("Value: " + str(value))

    hr()

    #paragraph("There are " + str(len(d['entries'])) + " entries.")

    #for de in d.entries:
        #link_to(de['link'], de['title'])
        ##br()
        #paragraph()
 
    hr()

    end_body()
    
    end_html()
