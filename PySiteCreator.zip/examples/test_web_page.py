
import sys
import psc_util
from psc_util import *

def create():


    start_html()
    
    start_head()
    title("Testing DSLWiki")
    end_head()
    
    start_body()
    
    paragraph("""This is a paragraph This is a paragraph This is a paragraph     
    This is a paragraph This is a paragraph This is a paragraph This is a 
    paragraph This is a paragraph This is a paragraph This is a paragraph 
    This is a paragraph This is a paragraph This is a paragraph""")
    
    paragraph("A horizontal rule")
    
    hr()

    start_bold()
    paragraph("This is a paragraph in bold text")
    end_bold()

    paragraph("A horizontal rule")
    hr()

    start_ul()
        
    start_li()
    paragraph("An unordered list item 1")
    end_li()
    
    start_li()
    paragraph("An unordered list item 2")
    end_li()
    
    end_ul()
    
    paragraph("A horizontal rule")
    
    hr()
        
    start_ol()
        
    start_li()
    paragraph("An ordered list item 1")
    end_li()
    
    start_li()
    paragraph("An ordered list item 2")
    end_li()
    
    end_ol()
    
    paragraph("A horizontal rule")
    
    hr()
    
    end_body()
    
    end_html()
    
