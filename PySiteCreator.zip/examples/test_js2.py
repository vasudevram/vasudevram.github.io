
import sys
import psc_util
from psc_util import *

def write_js():
    paragraph("""
<!-- Start chat message --> 
<p align="center"> 
<i>Welcome to DancingBison.com - Live Chat.</i> 
</p> 
<!-- End welcome message --> 
 
<hr/> 
<!-- Start table for Live Chat --> 
<table border="1" cellspacing="8" align="center"> 
<tr> 
 
<td> <!-- Column 1 of table --> 
<script src="http://www.gmodules.com/ig/ifr?url=http://www.google.com/ig/modules/googletalk.xml&amp;synd=open&amp;w=320&amp;h=451&amp;title=Live+Chat&amp;lang=en&amp;country=US&amp;border=%23ffffff%7C3px%2C1px+solid+%23999999&amp;output=js"></script> 
</td> 
 
</tr> 
</table> 
 
<!-- End table for Live Chat --> 
<hr/> 
    """)
    
def create():

	start_html()

	start_head()
	title("A title")
	end_head()

	start_body()

	hr()
	paragraph("JS below here")

	hr()
	
	write_js()
	
	end_body()

	end_html()

