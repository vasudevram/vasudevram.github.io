
import sys
import psc_util
from psc_util import *

def create():

    start_html()
    
    start_head()
    title("Testing DSLWiki")
    end_head()
    
    start_body()
    
    paragraph("""This is a paragraph""")
    paragraph("A horizontal rule")
    hr()
    link_to("MainPage.html", "MainPage")
    start_bold()
    paragraph("This is bold text")
    end_bold()
    
    start_italic()
    paragraph("This is italic text")
    end_italic()
    
    end_body()
    
    end_html()
