
This file was created by Vasudev Ram - http://www.dancingbison.com .

This is the README.txt file (the documentation) for the PySiteCreator tool.

License: The software files in this package are open source code, 
released under the New BSD License - see:

http://www.opensource.org/licenses/bsd-license.php

Note: Read the entire documentation in this file before starting 
to install any of the software mentioned below.


Description of PySiteCreator:

PySiteCreator is a tool that allows the user to create Web (HTML) 
sites by writing them entirely in Python. A user creates one or more 
Python source files in each of which they import a PySiteCreator helper 
module, and then call helper functions defined in that module, in order 
to emit HTML elements and associated content. They can then run the 
PySiteCreator program to process all those Python files; processing 
each Python file will result in the creation of a corresponding HTML 
file with the desired HTML elements and content.

A useful feature of PySiteCreator is that it allows you to write 
almost any Python code you wish, that can fetch data from any source, 
for outputting to the created HTML files. The data can be fetched from 
text files, CSV files, DBM files, any type of file in the file system 
from which you can fetch data by any means, from a relational database 
using the Python DB API, from any source on the Internet, using sockets, 
XML-RPC calls, HTTP REST calls, SOAP calls, CORBA, PYRO, RPyC, or any 
other suitable method. 

There are only a few conventions to be followed, such as importing the 
psc_util module in each Python file your write, and defining a top-level 
function in each file, that should be named create(), in order to be able 
to use PySiteCreator. Other than those conventions, there are no other 
restrictions or requirements about what kind of code you write in the 
Python files.


Requirements for PySiteCreator:

- The only software requirement for running PySiteCreator is Python 
itself. PySiteCreator has been developed and tested using Python 
v2.6.1. It may also work with some earlier versions of Python, but that 
is not guaranteed. You can try it out, though.

Installation of Python:

If you already have Python 2.6.1 or higher installed, you can skip 
this section.

Install Python v2.6.1 or higher. (It is preferable to get the latest 
stable Python version, which is v2.6.x at the time of writing this file.) 
Get it from http://python.org and install it, if you don't already have 
it. To check whether it is working, after installation, go to a terminal 
window (on UNIX-like systems) or a command prompt (on Windows) and type:

  python -V

If you get a message showing the Python version installed, it means the 
installation went ok. If you get some other message indicating an error, 
it means that Python was not installed ok. If not installed ok, get help 
from some local expert.


Installation of PySiteCreator:

- Since you are reading this README.txt file which comes with 
PySiteCreator, I assume that you have already downloaded the 
zip file PySiteCreator.zip into some temporary directory. If not,
you can download it from this URL:

    http://www.dancingbison.com/products.html#PySiteCreator

- Create a program directory in which to install PySiteCreator.

If your operating system is UNIX-like (e.g. some version of UNIX or 
Linux or one of the BSD's or Mac OS X - all abbreviated as UNIX from 
now on), let's assume that the program directory is called 
/home/you/software/PySiteCreator.

If your operating system is Windows, let's assume that the program 
directory is called D:\Software\PySiteCreator.

- Extract (uncompress) the contents of the PySiteCreator.zip file into 
the program directory. Make sure to use the option of your extraction / 
uncompression program (such as WinZip or 7-Zip if on Windows, or unzip 
if on UNIX), that specifies creation of subdirectories corresponding to 
those in the zip file.

- Add the program directory to your PYTHONPATH environment variable.

To do that, use a command like one of the examples below;

On UNIX, if using a bash-like shell (sh, ksh or bash):

$ export PYTHONPATH=$PYTHONPATH:/home/you/software/PySiteCreator

On UNIX, if using a csh-like shell:

$ setenv PYTHONPATH $PYTHONPATH:/home/you/software/PySiteCreator

On Windows:

D:> set PYTHONPATH=%PYTHONPATH%;D:\Software\PySiteCreator

- If you want to be able to run PySiteCreator from any directory, 
add the program directory to your PATH environment variable.

To do that, use a command like one of the examples below;

On UNIX, if using a bash-like shell (sh, ksh or bash):

$ export PATH=$PATH:/home/you/software/PySiteCreator

On UNIX, if using a csh-like shell:

$ setenv PATH $PATH:/home/you/software/PySiteCreator

On Windows:

D:> set PATH=%PATH%;D:\Software\PySiteCreator


Running PySiteCreator:

- Create a directory for your current project that will use 
PySiteCreator. If on UNIX, let's assume that the project directory 
is called /home/you/data/your_psc_project. If on Windows, let's 
assume that the project directory is called D:\Data\YourPSCProject.
Then, at a UNIX shell or Windows DOS prompt, make the project directory 
your current directory, i.e. do a cd (change directory) to it:

On UNIX:

$ cd /home/you/data/your_psc_project

On Windows:

D:> cd D:\Data\YourPSCProject

- For each web (HTML) page that you want to create using PySiteCreator, 
write a Python source code file (in the project directory) that imports 
the PySiteCreator helper module psc_util (which is in file psc_util.py 
in the program directory). Let's call one such file, main_page.py.

- In main_page,py, you can then call various helper functions which 
are defined in module psc_util, to output HTML elements and associated 
text or other content into the HTML file that will be created when you 
run PySiteCreator on your project's Python files. The examples sub-
directory of the PySiteCreator program directory should contain some 
.py files which are meant to be run by PySiteCreator; you can use these 
to learn how to use the helper functions to create HTML content.

(The helper functions are very easy to use; in most cases, each helper 
function corresponds to the name of some HTML element, like the <html> 
element, the <head> element, the <p> element, the <table> element, and 
so on. Each helper function also has a Python docstring associated with 
it; so, to explore the functions and their intended use, you can browse 
those function docstrings at the Python interpreter prompt, after you 
import the psc_util module into the interpreter session, or you can 
browse the docstrings in a Python IDE of your choice, which supports 
browsing function docstrings, again, possibly, after importing the 
psc_util module into the IDE.)

- After creating all the Python files for your project, you can run 
the PySiteCreator.py program using the Python interpreter, from the 
command-line, with the project directory as the command-line argument, 
like this:

On UNIX:

$ python PySiteCreator.py /home/you/data/your_psc_project 
(which should work no matter which directory you are currently in)

On Windows:

D:> python PySiteCreator.py D:\Data\YourPSCProject

or like this:

This command will start PySiteCreator and make it run all the Python 
files in the project directory. Running each such Python (.py) file, 
will result in the creation of a corresponding HTML (.html) file with 
the same basename as the .py file. The .html file will be created if 
it does not exist, or if the .py file's creation / modification time 
is more recent than that of the .html file.


Note: If you need some customization of PySiteCreator (such as adding 
features to it, or improving existing features, or help using it to 
create Web (HTML) sites, or any other Python programming work, 
I am available for that, on a paid basis. I also have skills in, and 
work with, many other technologies, such as Java, relational databases, 
Ruby, Linux, C, and many open source technologies. Please feel free to 
contact me via my business web site; the contact page is:

http://www.dancingbison.com/contact.html

You can also visit the following pages of my business web site to get 
more information about my skills, experience, software products, 
articles written, etc.:

Home: http://www.dancingbison.com
Products: http://www.dancingbison.com/products.html
Services: http://www.dancingbison.com/services.html
About: http://www.dancingbison.com/about.html


I appreciate all feedback about this software. That includes bug reports 
and feature requests. I can't guarantee that I'll implement any requested 
features for free, but will definitely give consideration to all such 
requests. Also, if you're using the PySiteCreator software, even if you 
don't have any problems with it, or any feature requests, I'd appreciate 
your telling me how you find it, and what you use it for, if that's not 
confidential. 

Thanks,
Vasudev Ram
Dancing Bison Enterprises
Software products, consulting and training
Biz site: http://www.dancingbison.com
Blog on software innovation: http://jugad2.blogspot.com
Twitter: @vasudevram

--------------------------- END OF FILE ---------------------------
