
# PySiteCreator.py
# Author: Vasudev Ram - http://www.dancingbison.com

# This file is a part of the PySiteCreator software package.

# The PySiteCreator software is released under the BSD License.
# The following are the terms of the license.
# 
# Copyright (c) 2009, Vasudev Ram
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the following
# conditions are met:
# 
#  - Redistributions of source code must retain the above copyright
# notice, this list of conditions and the following disclaimer. 
# 
#  - Redistributions in binary form must reproduce the above 
# copyright notice, this list of conditions and the following
# disclaimer in the documentation and/or other materials
# provided with the distribution.
# 
#  - Neither the name of Vasudev Ram nor the names of any
# contributors may be used to endorse or promote products
# derived from this software without specific prior written
# permission. 
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

# --------------------------------------------------------------

# Description: 
# PySiteCreator is a program to enable users to create HTML pages by 
# writing Python code. The PySiteCreator program then runs those
# Python code files to generate the desired HTML pages.

# --------------------------------------------------------------

#---------------- imports --------------------------------------

import sys
import os
import os.path
import traceback

import psc_util

#---------------- globals --------------------------------------

# Program name for error messages
prog_name = None

# Debug flag
DEBUG = 0

#---------------- helper functions -----------------------------

#---------------------- debug() --------------------------------

def debug(expr, value=None, out=sys.stderr):
	"""
	Function to debug the program.
	Arguments:
	- expr: an expression to print.
	- value: a value to print, which may correspond to the
	expression's value. Optional argument.
	- out: output file-like object on which to print the output.
	Optional argument. Defaults to sys.stderr.
	"""

	global DEBUG
	#print "In debug(): DEBUG = %r" % repr(DEBUG)
	if (DEBUG != 1):
		return
	if value is None:
	# print only 'expr' if 'value' is None
		msg = "%s\n" % (str(expr))
	else:
	# print both expr and value if value is not None
		msg = "%s = %r\n" % (str(expr), repr(value))
	out.write(msg)
	out.flush()

#------------------------ set_debug_flag() ---------------------

def set_debug_flag():
	"""
	Function to set the flag DEBUG to 0 (False) or 1 (True) based on
	the value of the environment variable of the same name.
	If env. var. DEBUG is unset, or is set but not equal to "1",
	set DEBUG to 0, else set it to 1.
	Arguments: No arguments.
	"""

	global DEBUG
	#DEBUG = 0
	debug_env_var = os.getenv("DEBUG")
	sys.stderr.write("DEBUG environment variable = %s\n" % debug_env_var)
	if not debug_env_var in (None, "0", "1"):
		sys.stderr.write(
		"%s: Error: DEBUG environment variable should be undefined, " +
		"0 or 1\n" % prog_name)
		sys.exit(1)
	if debug_env_var is None:
		debug_env_var = "0"
	# Now debug_env_var is either "0" or "1", so convert it to int and
	# return it.
	return int(debug_env_var)

#---------------- error_exit() --------------------------

def error_exit(message, err_fil=sys.stderr):
	"""
	Function to write the given error message to the error file
	object err_fil, with a prefix and suffix, then exit.
	Arguments:
	- message: the message to write out.
	- err_fil: file-like object to which to write the message.
	Optional argument. Defaults to sys.stderr.
	"""

	global prog_name

	try:
		err_fil.write(prog_name + ": " + message);
		err_fil.write("Exiting.\n");
		err_fil.flush();
	except IOError:
		print "%s: IOError while writing to error file object. " + \
			"Exiting." % prog_name
	sys.exit(1)

#---------------- get_html_filename_from_py() --------------

def get_html_filename_from(py_filename):
	"""
	Function to derive the .html filename from the .py filename.
	Arguments:
	- py_filename: name of the .py file.
	Returns:
	The .html filename derived from the .py filename.
	"""

	debug("Entered get_html_filename_from(), py_filename", py_filename)
	assert py_filename is not None
	html_filename = os.path.splitext(py_filename)[0] + ".html"
	debug("Leaving get_html_filename_from(), html_filename", html_filename)
	return html_filename

#---------------- usage() ----------------------------------

def usage(out_fil=sys.stderr):
	"""
	Function to write a usage message to the specified file object out_fil.
	Arguments:
	- out_fil: file-like object to write the usage message to. Optional
	argument. Defaults to sys.stderr.
	"""

	global prog_name

	try:
		out_fil.write("\nUsage: %s page_directory\n" % prog_name)
		out_fil.flush()
	except IOError:
		error_exit("IOError while writing to output file.\n")
	except:
		error_exit("Unexpected error while writing to output file.\n")

#---------------- write_error() ----------------------------

def write_error(message, err_fil=sys.stderr):
	"""
	Function to write an error message to the file object err_fil.
	Arguments:
	- message: the message to write.
	- err_fil: the file-like object to which to write the message.
	Optional argument. Defaults to sys.stderr.
	"""

	try:
		err_fil.write(message)
		err_fil.flush()
	except IOError:
		error_exit("IOError while writing to error file.\n")
	except:
		error_exit("Unexpected error while writing to error file.\n")
	
#---------------- get_file_mod_times() ---------------------

def get_file_mod_times(filenames):
	"""
	Function to get and return the last modification times for all the
	filenames given in the sequence argument.
	Arguments:
	- filenames: sequence of filenames whose last modification times
	are to be returned.
	Returns: a list of file modification times in the format returned
	by os.stat(filename).st_mtime.
	"""

	file_mod_times = []
	##TODO: Using plain except below. Should maybe use more specific
	##TODO: exception class. But while developing on Windows, getting
	##TODO: WindowsError for failed os.stat() call. So using plain
	##TODO: for now to avoid making the check OS-specific.
	try:
		for filename in filenames:
			file_mod_times.append(os.stat(filename).st_mtime)
	except:
		error_exit("Error while calling os.stat(%s)" % filename)
	return file_mod_times

#---------------- generate_html_file() ---------------------

def generate_html_file(page_dir, py_filename, py_module_name, html_filename):
	"""
	Function to generate the .html file from the .py file by running
	the py_module_name.create() function defined in the py_filename.
	Arguments:
	- page_dir: the directory in which the .py files exist, and in which
	the corresponding .html files will be created.
	- py_filename: the filename of the Python file to run to create
	the corresponding HTML file.
	- py_module_name: the name of the Python module defined by the
	file py_filename.
	- html_filename: the name of the HTML file that will be created
	corresponding to, and with the same basename as, the Python file.
	Returns: Nothing - only does actions.
	"""

	debug("Entered generate_html_file")

	# Open the .html file for writing.
	try:
		html_fil = open(html_filename, "w")
	except IOError:
		error_exit("IOError opening output HTML file %s\n" % html_filename)
	except:
		error_exit("Unexpected error opening output HTML file %s\n" % html_filename)

	# Set the output destination to html_fil.
	debug("In generate_html_file(), before psc_util.set_output_dest(), html_fil", html_fil)
	psc_util.set_output_dest(html_fil)

	##TODO: Put the code to copy the dict of main to a new dict, and
	# then to use that new dict in the __import__() call below, here.

	# Import the .py file and run the create() function in it.
	try:
		#exec "import " + py_module_name + \
		#" as mod_name in globals(), locals()"
		debug("Before __import__, py_module_name = ", py_module_name)
		debug("Before __import__, sys.path = ", sys.path)
		mod_name = __import__(py_module_name, globals(), locals())
			#" as mod_name in globals(), locals()"
		debug("After __import__, mod_name", mod_name)
		# Call the create() function defined in the module mod_name.
		mod_name.create()
		debug("After mod_name.create() call")
		##TODO: Put code to do a 'del mod_name' here and then check if
		# it is needed and if it works.
	except Exception, e:
		traceback.print_exc(file=sys.stderr)
		err_msg = "Error importing module %s or error running function create() from input Python file %s\n" % (py_module_name, py_filename)
		error_exit(err_msg)
	# Catchall to handle any unforeseen exceptions that may arise due to
	# use of __import__() function and call to create() function.
	except:
		error_exit("Unexpected error encountered while running input Python file %s\n" % (py_filename))

	try:
		html_fil.close()
	except IOError:
		error_exit("IOError closing output HTML file %s\n" % html_filename)
	except:
		error_exit("Unexpected error closing output HTML file %s\n" % html_filename)

	print "Generated %s from %s" % (html_filename, py_filename)

#---------------- main() -----------------------------------
	
def main():

	global prog_name
	global DEBUG

	print "Before DEBUG = set_debug_flag(), DEBUG = %r" % DEBUG
	DEBUG = set_debug_flag()
	print "After DEBUG = set_debug_flag(), DEBUG = %r" % DEBUG
	
	# Save program name for error messages
	prog_name = sys.argv[0]

	if len(sys.argv) < 2:
		usage()
		sys.exit(1)

	# Save the current directory for restoring later.
	orig_dir = os.getcwd()

	# page_dir is the name for the directory in which the .py files
	# exist, and in which the corresponding .html files will be created.
	page_dir = sys.argv[1]
	# Check if the specified page directory exists; exit if not.
	if not os.path.exists(page_dir):
		usage()
		sys.exit(1)
	# Convert the directory name page_dir to its absolute path.
	page_dir = os.path.abspath(page_dir)
	debug("After using abspath, page_dir", page_dir)

	# Change to the page_dir directory; exit if cannot change to it.
	try:
		os.chdir(page_dir)
		debug("os.getcwd", os.getcwd())
	except Exception:
		write_error(
			"Could not change to page directory %s. Exiting." % page_dir)
		sys.exit(1)

	# Add the page_dir at THE BEGINNING of sys.path.
	sys.path.insert(0, page_dir)
	debug("After insert of page_dir, sys.path", sys.path)

	# Add orig_dir to THE END of sys.path. NOTE: It is deliberately added
	# to sys.path AT THE END.

	debug("Before append of orig_dir, sys.path", sys.path)
	sys.path.append(orig_dir)
	debug("After append of orig_dir, sys.path", sys.path)

	# Run the module_name.create() function for all Python modules (files 
	# with extension ".py") for which there is no file with the same 
	# basename and extension ".html", or for which the .html file's 
	# modification time is older than that of the .py file.
	print "Processing files in directory", page_dir
	dirlist = os.listdir(".")
	debug("dirlist", dirlist)
	# Loop over all files in current directory, but process only
	# the .py files.
	for filename in dirlist:
		if not filename.endswith(".py"):
			continue
		else:
			print "Checking file %s ... " % filename
		py_filename = filename
		py_module_name = os.path.splitext(py_filename)[0]
		debug("py_module_name", py_module_name)
		html_filename = get_html_filename_from(py_filename)
		debug("html_filename", html_filename)
		generate_html = False
		# If the .html file doesn't exist, generate it.
		if not os.path.exists(html_filename):
			generate_html = True
		else:
			# Get the modification times of the .py and .html files.
			(pyfile_mod_time, htmlfile_mod_time) = \
					get_file_mod_times((py_filename, html_filename))
			# If the .py file is newer than the .html file, generate the
			# .html file.
			if (pyfile_mod_time > htmlfile_mod_time):
				generate_html = True
		if generate_html:
			# Generate the .html file by running the .py file.
			generate_html_file(page_dir, py_filename, py_module_name, 
				html_filename)

	# Change back to the original directory; exit if cannot change to it.
	try:
		os.chdir(orig_dir)
		debug("os.getcwd", os.getcwd())
	except Exception:
		write_error(
		"Could not change to original directory %s. Exiting." % orig_dir)
		sys.exit(1)

#----------------------------- Run main() -----------------------

if __name__ == "__main__":
	main()

#----------------------------- EOF: PySiteCreator.py ------------------

