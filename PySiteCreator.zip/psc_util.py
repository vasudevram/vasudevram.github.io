
# psc_util.py
# Author: Vasudev Ram - http://www.dancingbison.com

# This file is a part of the PySiteCreator software package.

# The PySiteCreator software is released under the BSD License.
# The following are the terms of the license.
# 
# Copyright (c) 2009, Vasudev Ram
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the following
# conditions are met:
# 
#  - Redistributions of source code must retain the above copyright
# notice, this list of conditions and the following disclaimer. 
# 
#  - Redistributions in binary form must reproduce the above 
# copyright notice, this list of conditions and the following
# disclaimer in the documentation and/or other materials
# provided with the distribution.
# 
#  - Neither the name of Vasudev Ram nor the names of any
# contributors may be used to endorse or promote products
# derived from this software without specific prior written
# permission. 
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

# --------------------------------------------------------------

# Description: 
# PySiteCreator is a program to enable users to create HTML pages by 
# writing Python code. The PySiteCreator program then runs those
# Python code files to generate the intended HTML pages.

# --------------------------------------------------------------

import sys

# Set out_fil_dest[0] to a dummy value for now. Actual value
# will be provided by call to set_output_dest() from caller.

out_fil_dest = [ sys.stdout ]

#---------------- set_output_dest() ------------------------------

def set_output_dest(out_fil):
	"""
	Set the output destination.
	"""
	global out_fil_dest

	#debug("Entered set_output_dest(), out_fil arg", out_fil)
	#sys.stderr.write("Entered set_output_dest(), out_fil = %s\n" % out_fil)

	out_fil_dest[0] = out_fil

#---------------- output() ---------------------------------------

def output(out_val):
	"""
	Write the given value, out_val, to the output destination.
	"""

	global out_fil_dest

	out_fil = out_fil_dest[0]
	try:
		out_fil.write(out_val)
		out_fil.flush()
	except IOError:
		error_exit("IOError while writing to output file.\n")
	
#---------------- functions to create HTML elements -----

def start_html():

	output("\n<html>\n")

def end_html():

	output("\n</html>\n")

def start_head():

	output("\n<head>\n")

def end_head():

	output("\n</head>\n")

def start_title():

	output("\n<title>\n")
	
def end_title():

	output("\n</title>\n")

def title(str):

	start_title()
	output(str)
	end_title()

def start_body():

	output("\n<body>\n")

def end_body():

	output("\n</body>\n")

def paragraph(str=""):

	output("\n<p>" + str + "</p>" + "\n")
	
def preformatted(str):

	output("\n<pre>" + str + "</pre>" + "\n")
	
def start_bold():

	output("<b>")

def end_bold():

	output("</b>")
	
def start_italic():

	output("<i>")

def end_italic():

	output("</i>")
	
def start_underline():

	output("<u>")

def end_underline():

	output("</u>")
	
def start_ul():

	output("<ul>\n")

def end_ul():

	output("</ul>\n")
	
def start_li():

	output("<li>\n")

def end_li():

	output("</li>\n")
	
def start_ol():

	output("<ol>\n")

def end_ol():

	output("</ol>\n")

def start_table():

	output('\n<table border="1" cellspacing="5">\n')
	
def end_table():

	output("\n</table>\n")

def start_table_row():

	output("\n<tr>\n")
	
def end_table_row():

	output("\n</tr>\n")

def start_table_header():

	output("\n<th>\n")
	
def end_table_header():

	output("\n</th>\n")

def start_table_detail():

	output("\n<td>\n")
	
def end_table_detail():

	output("\n</td>\n")

def link_to(url, title):

	output('<a href="' + url + '">' + title + '</a>')

def hr():

	output("<hr/>\n")

def br():

	output("<br/>\n")

#----------------------------- EOF: psc_util.py ------------------

